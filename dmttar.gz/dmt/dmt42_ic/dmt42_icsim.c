/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt42_ictype.h"
#include "dmt42_icext.h"
/******************************************************************************/
int Simulation()
{
 for(Frame_Cnt=ZERO;Frame_Cnt<MAX_FRAMES;Frame_Cnt++)
 {
  Get_Frame();
  Init_Avg();
  for(Rep_Cnt=ZERO;Rep_Cnt<NUM_RE_TX;Rep_Cnt++)
  {
   for(Blk_Cnt=ZERO;Blk_Cnt<NUM_BLKS;Blk_Cnt++)
   {
    Get_Chan();
    Get_Noise();
    Get_Rx_Signal();
    Chan_H_Mult();
   }
  }
  Receive();
 }
 return(0);
}
/******************************************************************************/
/*                 Initialize the average channel and noise.
*******************************************************************************/
int Init_Avg()
{
 int cnt;
 for(cnt=ZERO;cnt<2*FRAME_SIZE;cnt++)
 {
  Avg_Diag[cnt]=0.0;
  Avg_Rx_Sig[cnt]=0.0+0.0*I;
 }
 return(0);
}
/******************************************************************************/
/*                         Get the channel matrix.
*******************************************************************************/
int Get_Chan()
{
 int rows,cols;
 double erand48();
 for(rows=ZERO;rows<NUM_TX;rows++)
 {
  for(cols=ZERO;cols<NUM_TX;cols++)
  {
   C1_Val[URADIUS]=erand48(C1_Store);
   C1_Val[UTHETA] =erand48(C2_Store);
   My_Gauss(C_Variance,C1_Val);
   Chan[rows][cols]=C1_Val[GRAND_0]+C1_Val[GRAND_1]*I;
//   printf("r:%d c:%d ",rows,cols);
//   printf("ch:%lf+I*%lf\n",creal(Chan[rows][cols]),cimag(Chan[rows][cols]));
  }
 }
 return(0);
}
/******************************************************************************/
/*                        Add white Gaussian noise.
*******************************************************************************/
int Get_Noise()
{
 int cnt;
 double erand48();
 for(cnt=ZERO;cnt<NUM_TX;cnt++)
 {
  N1_Val[URADIUS]=erand48(N1_Store);
  N1_Val[UTHETA]= erand48(N2_Store);
  My_Gauss(Variance,N1_Val);
  Noise[cnt]=N1_Val[GRAND_0]+N1_Val[GRAND_1]*I;
 }
 return(0);
}
/******************************************************************************/
/*                        Get the received signal.
*******************************************************************************/
int Get_Rx_Signal()
{
 int blk_st_inx,cnt,cnt1;
 blk_st_inx=Blk_Cnt*NUM_TX;
 for(cnt=ZERO;cnt<NUM_TX;cnt++)
 {
  Rx_Sig[cnt]=0.0+0.0*I;
  for(cnt1=ZERO;cnt1<NUM_TX;cnt1++)
   Rx_Sig[cnt]=Rx_Sig[cnt]+Chan[cnt][cnt1]*QPSK_Sym[cnt1+blk_st_inx];
  Rx_Sig[cnt]=Rx_Sig[cnt]+Noise[cnt];
 }
 return(0);
}
/******************************************************************************/
/*                     Multiply with the channel Hermitian.
*******************************************************************************/
int Chan_H_Mult()
{
 int cnt1,cnt2,cnt4;
 double diag,x;
 double complex rx_sig;
 for(cnt1=ZERO;cnt1<NUM_TX;cnt1++)
 {
  diag=0.0;
  rx_sig=0.0+0.0*I;
  for(cnt2=ZERO;cnt2<NUM_TX;cnt2++)
  {
   rx_sig=rx_sig+conj(Chan[cnt2][cnt1])*Rx_Sig[cnt2];
   x=cabs(Chan[cnt2][cnt1]);
   diag=diag+x*x;
  }
  cnt4=Blk_Cnt*NUM_TX+cnt1;
  Avg_Rx_Sig[cnt4]=Avg_Rx_Sig[cnt4]+rx_sig;
  Avg_Diag[cnt4]=Avg_Diag[cnt4]+diag;
//  printf("time:%d diag:%lf ",cnt4,Avg_Diag[cnt4]);
//  printf("avg rx sig re:%lf ",creal(Avg_Rx_Sig[cnt4]));
//  printf("im:%lf\n",cimag(Avg_Rx_Sig[cnt4]));
 }
 return(0);
}
/******************************************************************************/
/*                            Receiver routines.
*******************************************************************************/
int Receive()
{
 Get_Avg();
 Init_Gamma();
 Init_App();
 Bcjr();
 Get_Bit_Errors_Dec1();
 return(0);
}
/******************************************************************************/
/*                Get the avg rx signal and diagonal elements.
*******************************************************************************/
int Get_Avg()
{
 int cnt;
 for(cnt=ZERO;cnt<2*FRAME_SIZE;cnt++)
 {
  Avg_Rx_Sig[cnt]=Avg_Rx_Sig[cnt]/(double complex)NUM_RE_TX;
  Avg_Diag[cnt]=Avg_Diag[cnt]/(double)NUM_RE_TX;
 }
 return(0);
}
/******************************************************************************/
/*                   Initialize gamma for decoder 1 and 2.
*******************************************************************************/
int Init_Gamma()
{
 int time,sym_cnt,time1;
 double x,y,max1,max2;
 double complex sym;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  time1=time+FRAME_SIZE;
  max1=max2=MIN_MAG;
  for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  {
   sym=QPSK_Map[sym_cnt];
   x=cabs(sym*Avg_Diag[time] -Avg_Rx_Sig[time]);
//   printf("init gamma ti:%d sym cnt:%d ",time,sym_cnt);
//   printf("x:%lf max1:%lf\n",x,max1);
   y=cabs(sym*Avg_Diag[time1]-Avg_Rx_Sig[time1]);
   Gamma_1[time][sym_cnt]= -x*x*Inv_Int_Var;
   Gamma_2[time][sym_cnt]= -y*y*Inv_Int_Var;
   if(Gamma_1[time][sym_cnt] > max1)
    max1=Gamma_1[time][sym_cnt];
   if(Gamma_2[time][sym_cnt] > max2)
    max2=Gamma_2[time][sym_cnt];
  }
//  printf("init gamma ti:%d ",time);
//  printf("max1:%lf\n",max1);
  Get_Norm_Gamma(time,max1,max2);
 }
 return(0);
}
/******************************************************************************/
/*              Get the normalized gamma for decoder 1 and 2.
*******************************************************************************/
int Get_Norm_Gamma(time,max1,max2)
int time;
double max1,max2;
{
 int sym_cnt;
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
 {
//  printf("bnorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=Gamma_1[time][sym_cnt]-max1;
  Gamma_2[time][sym_cnt]=Gamma_2[time][sym_cnt]-max2;
  if(Gamma_1[time][sym_cnt] < MIN_EXPO)
   Gamma_1[time][sym_cnt]=MIN_EXPO;
  if(Gamma_2[time][sym_cnt] < MIN_EXPO)
   Gamma_2[time][sym_cnt]=MIN_EXPO;
//  printf("anorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=exp(Gamma_1[time][sym_cnt]);
  Gamma_2[time][sym_cnt]=exp(Gamma_2[time][sym_cnt]);
 }
 return(0);
}
/******************************************************************************/
/*                Initialize the a posteriori probabilities.
*******************************************************************************/
int Init_App()
{
 int time,input;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  for(input=ZERO;input<NUM_INPUTS;input++)
   Prob[time][input]=0.5;
 }
 return(0);
}
/******************************************************************************/
/*                          The BCJR algorithm.
*******************************************************************************/
int Bcjr()
{
 for(Iter=ZERO;Iter<MAX_ITER;Iter++)
 {
  Dec2_Process();
  Dec1_Process();
 }
 return(0);
}
/******************************************************************************/
/*    Finally compute the number of bit errors in the frame from decoder1.
*******************************************************************************/
int Get_Bit_Errors_Dec1()
{
 int time,detected_bit,act_bit;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  detected_bit=ONE;
  if(Prob[time][ZERO] > Prob[time][ONE])
   detected_bit=ZERO;
  act_bit=Bits[time];
  if(detected_bit != Bits[time])
   Ber++;
 }
 return(0);
}
/******************************************************************************/
/*                       Print out the probabilities.
*******************************************************************************/
int Print_Prob()
{
 int time,act_bit;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  act_bit=Bits[time];
  printf("Print prob Frame:%d time:%d tx bit:%d ",Frame_Cnt,time,act_bit);
  printf("Prob 0:%lf  ",Prob[time][0]);
  printf("Prob 1:%lf\n",Prob[time][1]);
 }
 return(0);
}
/******************************************************************************/
