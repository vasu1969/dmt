/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt42_ictype.h"
#include "dmt42_icext.h"
/******************************************************************************/
int Get_Iv_Map()
{
 int ck_iv_inx[IV_SIZE];
 double iv_noise_val[IV_SIZE];
 Get_Uniform_Noise(iv_noise_val);
 Init_Ck_Iv_Inx(ck_iv_inx);
 Get_Iv_Elements(iv_noise_val,ck_iv_inx);
 Print_Iv_Map();
 Get_Min_Cycle_Length();
 return(0);
}
/******************************************************************************/
/*                   Get uniformly distributed noise.
*******************************************************************************/
int Get_Uniform_Noise(iv_noise_val)
double iv_noise_val[];
{
 int cnt;
 double erand48();
 for(cnt=ZERO;cnt<IV_SIZE;cnt++)
  iv_noise_val[cnt]=erand48(Iv_Noise_Store);
 return(0);
}
/******************************************************************************/
/*                 Initialize the interleaver check vector.
*******************************************************************************/
int Init_Ck_Iv_Inx(ck_iv_inx)
int ck_iv_inx[];
{
 int cnt;
 for(cnt=ZERO;cnt<IV_SIZE;cnt++)
  ck_iv_inx[cnt]=ZERO;
 return(0);
}
/******************************************************************************/
/*                        Get the interleaver map.
*******************************************************************************/
int Get_Iv_Elements(iv_noise_val,ck_iv_inx)
int ck_iv_inx[];
double iv_noise_val[];
{
 int cnt,max_inx,iv_inx;
 double max;
 for(iv_inx=ZERO;iv_inx<IV_SIZE;iv_inx++)
 {
  max=MIN_MAG;
  for(cnt=ZERO;cnt<IV_SIZE;cnt++)
  {
   if((ck_iv_inx[cnt] == ZERO) && (iv_noise_val[cnt] > max))
   {
    max=iv_noise_val[cnt];
    max_inx=cnt;
   }
  }
  ck_iv_inx[max_inx]=ONE;                    /* Dont check max_inx next time. */
  Iv_Map[iv_inx]=max_inx;                                 /* Interleaver map. */
  De_Iv_Map[max_inx]=iv_inx;                            /* Deinterleaver map. */
 }
 return(0);
}
/******************************************************************************/
/*                       Print the interleaver map.
*******************************************************************************/
int Print_Iv_Map()
{
 int cnt;
 printf("\t Interleaver map.\n\n");
 for(cnt=ZERO;cnt<IV_SIZE;cnt++)
 {
  printf("\t\t Iv. map Index:%5d Map:%5d\n",cnt,Iv_Map[cnt]);
  printf("\t\t Dv. map Index:%5d Map:%5d\n",cnt,De_Iv_Map[cnt]);
 }
 printf("\n");
 fflush(stdout);
 return(0);
}
/******************************************************************************/
/*                        Get the minimum cycle length.
*******************************************************************************/
int Get_Min_Cycle_Length()
{
 int cnt1,cnt2,diff,min,cycle_len;
 min=10*IV_SIZE;
 for(cnt1=ZERO;cnt1<IV_SIZE;cnt1++)
 {
  for(cnt2=cnt1+ONE;cnt2<IV_SIZE;cnt2++)
  {
   cycle_len=abs(cnt1-cnt2)+abs(Iv_Map[cnt1]-Iv_Map[cnt2]);
   if(cycle_len < min)
    min=cycle_len;
  }
 }
 printf("\t Min. cycle length:%d.\n\n",min);
 fflush(stdout);
 return(0);
}
/******************************************************************************/
