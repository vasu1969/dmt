/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt42_ictype.h"
#include "dmt42_icglob.h"
/******************************************************************************/
int main()
{
 printf("\t Preprocessor...\n\n");
 Pre_Processor();
 printf("\t Simulation...\n\n");
 Simulation();
 printf("\t Postprocessor...\n\n");
 Post_Processor();
 return(0);
}
/******************************************************************************/
