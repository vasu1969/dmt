/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt42_ictype.h"
#include "dmt42_icext.h"
/******************************************************************************/
/*                   Initialize simulation variables.
*******************************************************************************/
int Sim_Init()
{
 Noise_Gen_Init();
 Chan_Gen_Init();
 Get_Noise_Variance();
 Iv_Noise_Gen_Init();
 Ber_Init();
 return(0);
}
/******************************************************************************/
/*                     Initialize the noise generator.
*******************************************************************************/
int Noise_Gen_Init()
{
 int cnt;
 long int random(void);
 for(cnt=ZERO;cnt<PN_SIZE;cnt++)
 {
  N1_Store[cnt]=(unsigned short)random();
  N2_Store[cnt]=(unsigned short)random();
 }
 return(0);
}
/******************************************************************************/
/*                      Initialize the channel generator.
*******************************************************************************/
int Chan_Gen_Init()
{
 int cnt;
 long int random(void);
 for(cnt=ZERO;cnt<PN_SIZE;cnt++)
 {
  C1_Store[cnt]=(unsigned short)random();
  C2_Store[cnt]=(unsigned short)random();
 }
 C_Variance=0.5;                              /* Fade variance per dimension. */
 return(0);
}
/******************************************************************************/
/*                Get the noise variance per dimension of AWGN.
*******************************************************************************/
int Get_Noise_Variance()
{
 double num_tx,num_re_tx;
 num_tx=(double)NUM_TX;
 num_re_tx=(double)NUM_RE_TX;
 Variance=2.0*num_tx*num_re_tx/pow(10.0,0.1*SNR_B);
 printf("\t Noise variance:%lf.\n\n",Variance);
 Inv_Int_Var=8.0*num_tx*(num_tx-1.0)*C_Variance*C_Variance;
 Inv_Int_Var=Inv_Int_Var+4.0*num_tx*C_Variance*Variance;
 Inv_Int_Var=Inv_Int_Var/(double)NUM_RE_TX;
 Inv_Int_Var=1.0/Inv_Int_Var;
 printf("\t Inv. Interference variance:%lf.\n\n",Inv_Int_Var);
 return(0);
}
/******************************************************************************/
/*                Initialize the interleaver noise generator.
*******************************************************************************/
int Iv_Noise_Gen_Init()
{
 int cnt;
 long int random(void);
 for(cnt=ZERO;cnt<PN_SIZE;cnt++)
  Iv_Noise_Store[cnt]=(unsigned short)random();
 return(0);
}
/******************************************************************************/
/*                       Initialize the bit error rate.
*******************************************************************************/
int Ber_Init()
{
 Ber=ZERO;
 return(0);
}
/******************************************************************************/
