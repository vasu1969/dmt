/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
/*                                BIT VARIABLES.
*******************************************************************************/
int Bits[FRAME_SIZE];                                    /* Information bits. */
int Frame_Cnt;                                                /* Frame count. */
int Bit_Cnt;                                                    /* Bit count. */
int Ber;                                                   /* Bit error rate. */
int Blk_Cnt;                                                /* Block counter. */
int Rep_Cnt;                                           /* Repetition counter. */
/******************************************************************************/
/*                             ENCODER VARIABLES.
*******************************************************************************/
int Enc_State;                                              /* Encoder state. */
int Enc1_F_State;                                /* Final state of encoder 1. */
int Enc2_F_State;                                /* Final state of encoder 2. */
/******************************************************************************/
/*                       MAP TO CONSTELLATION VARIABLES.
*******************************************************************************/
double Bit_Map[CONSTELL_SIZE];                                /* Map to BPSK. */
double complex QPSK_Map[QPSK_SIZE];                           /* Map to QPSK. */
/******************************************************************************/
/*                   TRANSMITTED TURBO CODED QPSK SYMBOLS.
*******************************************************************************/
double complex QPSK_Sym[2*FRAME_SIZE];               /* Encoded QPSK symbols. */
/******************************************************************************/
/*                    VARIABLES RELATED TO INTERLEAVER.
*******************************************************************************/
int Iv_Map[IV_SIZE];                                  /* Interleaver mapping. */
int De_Iv_Map[IV_SIZE];                             /* Deinterleaver mapping. */
unsigned short Iv_Noise_Store[PN_SIZE];                 /* Stores PNS status. */
/******************************************************************************/
/*                            NOISE VARIABLES.
*******************************************************************************/
unsigned short N1_Store[PN_SIZE];                       /* Stores PNS status. */
unsigned short N2_Store[PN_SIZE];                       /* Stores PNS status. */
double Variance;                                           /* Noise variance. */
double Inv_Int_Var;                   /* Inverse of 2D interference variance. */
double N1_Val[NVALSIZE];                         /* Contains U & G rand. var. */
double complex Noise[NUM_TX];                    /* Noise vector for a block. */
/******************************************************************************/
/*                            CHANNEL VARIABLES.
*******************************************************************************/
unsigned short C1_Store[PN_SIZE];                       /* Stores PNS status. */
unsigned short C2_Store[PN_SIZE];                       /* Stores PNS status. */
double C_Variance;                               /* Channel variance per dim. */
double C1_Val[NVALSIZE];                         /* Contains U & G rand. var. */
double complex Chan[NUM_TX][NUM_TX];                     /* Channel matrix H. */
double complex CHC[NUM_BLKS][NUM_TX][NUM_TX];                       /* H^H*H. */
/******************************************************************************/
/*                            RECEIVED SIGNAL.
*******************************************************************************/
double complex Rx_Sig[NUM_TX];                     /* Rx. signal for 1 block. */
double complex Vec_Rx_Sig[2*FRAME_SIZE];                          /* Vec. rx. */
double Vec_Diag[2*FRAME_SIZE];                        /* Vec. diag. of H^H*H. */
double complex HD_QPSK[2*FRAME_SIZE];                            /* Rx. QPSK. */
double complex Int_Vec[2*FRAME_SIZE];                    /* Interference vec. */
/******************************************************************************/
/*                    VARIABLES RELATED TO THE TRELLIS.
*******************************************************************************/
int Enc_N[ENC_SIZE];                           /* Stores encoder numer. taps. */
int Enc_D[ENC_SIZE];                           /* Stores encoder denom. taps. */
int Trel_NS[NUM_STATES][NUM_INPUTS];                           /* Next state. */
int Trel_PS[NUM_STATES][NUM_INPUTS];                           /* Prev state. */
int Trel_Op[NUM_STATES][NUM_INPUTS];                              /* Outputs. */
int State_Inx[NUM_STATES];                    /* State index for Trel_PS[][]. */
/******************************************************************************/
/*                            BCJR VARIABLES.
*******************************************************************************/
int Iter;                                               /* Counts iterations. */
double Alpha[FRAME_SIZE][NUM_STATES];                              /* Alphas. */
double Beta[FRAME_SIZE_P1][NUM_STATES];                             /* Betas. */
double Gamma_1[FRAME_SIZE][QPSK_SIZE];                   /* Gamma for dec. 1. */
double Gamma_2[FRAME_SIZE][QPSK_SIZE];                   /* Gamma for dec. 2. */
double Prob[FRAME_SIZE][NUM_INPUTS];                   /* Data probabilities. */
double QProb[FRAME_SIZE][QPSK_SIZE];                   /* QPSK probabilities. */
/******************************************************************************/
