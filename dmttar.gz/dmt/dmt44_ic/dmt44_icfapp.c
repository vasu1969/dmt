/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt44_ictype.h"
#include "dmt44_icext.h"
/******************************************************************************/
/*             Compute the final APP ratios in the last iteration.
*******************************************************************************/
int Compute_Final_APPs_Dec1()
{
 int time;
 double fapp[NUM_INPUTS];
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  Get_Final_APP_Dec1(time,fapp);
  Get_Final_Prob_Dec1(time,fapp);
 }
 return(0);
}
/******************************************************************************/
/*      Get the final unnormalized probabilities in deinterleaved format.
*******************************************************************************/
int Get_Final_APP_Dec1(time,fapp)
int time;
double fapp[];
{
 int state,input,nxt_state,op,sym_cnt;
 double ge,prob,nxt_beta,prv_alpha;
 fapp[ZERO]=fapp[ONE]=0.0;
 for(state=ZERO;state<NUM_STATES;state++)
 {
  for(input=ZERO;input<NUM_INPUTS;input++)
  {
   nxt_state=Trel_NS[state][input];
   op=Trel_Op[state][input];
   sym_cnt=2*input+op;                                       /* QPSK sym num. */
   ge=Gamma_1[time][sym_cnt];                                     /* Gamma_1. */
   prob=Prob[time][input];
   prv_alpha=Alpha[time][state];
   nxt_beta=Beta[time+ONE][nxt_state];
   fapp[input]=fapp[input]+ge*prv_alpha*nxt_beta*prob;
  }
 }
 return(0);
}
/******************************************************************************/
/*     Get the final unnormalized probabilities in deinterleaved format.
*******************************************************************************/
int Get_Final_Prob_Dec1(time,fapp)
int time;
double fapp[];
{
 int input;
 double sum;
 sum=0.0;
 for(input=ZERO;input<NUM_INPUTS;input++)
  sum=sum+fapp[input];
 for(input=ZERO;input<NUM_INPUTS;input++)
  Prob[time][input]=fapp[input]/sum;
 return(0);
}
/******************************************************************************/
