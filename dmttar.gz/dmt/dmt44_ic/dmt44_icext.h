/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
/*                                BIT VARIABLES.
*******************************************************************************/
extern int Bits[FRAME_SIZE];                             /* Information bits. */
extern int Frame_Cnt;                                         /* Frame count. */
extern int Bit_Cnt;                                             /* Bit count. */
extern int Ber;                                            /* Bit error rate. */
extern int Blk_Cnt;                                         /* Block counter. */
extern int Rep_Cnt;                                    /* Repetition counter. */
/******************************************************************************/
/*                             ENCODER VARIABLES.
*******************************************************************************/
extern int Enc_State;                                       /* Encoder state. */
extern int Enc1_F_State;                         /* Final state of encoder 1. */
extern int Enc2_F_State;                         /* Final state of encoder 2. */
/******************************************************************************/
/*                       MAP TO CONSTELLATION VARIABLES.
*******************************************************************************/
extern double Bit_Map[CONSTELL_SIZE];                         /* Map to BPSK. */
extern double complex QPSK_Map[QPSK_SIZE];                    /* Map to QPSK. */
/******************************************************************************/
/*                   TRANSMITTED TURBO CODED QPSK SYMBOLS.
*******************************************************************************/
extern double complex QPSK_Sym[2*FRAME_SIZE];        /* Encoded QPSK symbols. */
/******************************************************************************/
/*                    VARIABLES RELATED TO INTERLEAVER.
*******************************************************************************/
extern int Iv_Map[IV_SIZE];                           /* Interleaver mapping. */
extern int De_Iv_Map[IV_SIZE];                      /* Deinterleaver mapping. */
extern unsigned short Iv_Noise_Store[PN_SIZE];          /* Stores PNS status. */
/******************************************************************************/
/*                            NOISE VARIABLES.
*******************************************************************************/
extern unsigned short N1_Store[PN_SIZE];                /* Stores PNS status. */
extern unsigned short N2_Store[PN_SIZE];                /* Stores PNS status. */
extern double Variance;                                    /* Noise variance. */
extern double Inv_Int_Var;            /* Inverse of 2D interference variance. */
extern double N1_Val[NVALSIZE];                  /* Contains U & G rand. var. */
extern double complex Noise[NUM_TX];             /* Noise vector for a block. */
/******************************************************************************/
/*                            CHANNEL VARIABLES.
*******************************************************************************/
extern unsigned short C1_Store[PN_SIZE];                /* Stores PNS status. */
extern unsigned short C2_Store[PN_SIZE];                /* Stores PNS status. */
extern double C_Variance;                        /* Channel variance per dim. */
extern double C1_Val[NVALSIZE];                  /* Contains U & G rand. var. */
extern double complex Chan[NUM_TX][NUM_TX];              /* Channel matrix H. */
extern double complex CHC[NUM_BLKS][NUM_TX][NUM_TX];                /* H^H*H. */
/******************************************************************************/
/*                            RECEIVED SIGNAL.
*******************************************************************************/
extern double complex Rx_Sig[NUM_TX];              /* Rx. signal for 1 block. */
extern double complex Vec_Rx_Sig[2*FRAME_SIZE];                   /* Vec. rx. */
extern double Vec_Diag[2*FRAME_SIZE];                 /* Vec. diag. of H^H*H. */
extern double complex HD_QPSK[2*FRAME_SIZE];                     /* Rx. QPSK. */
extern double complex Int_Vec[2*FRAME_SIZE];             /* Interference vec. */
/******************************************************************************/
/*                    VARIABLES RELATED TO THE TRELLIS.
*******************************************************************************/
extern int Enc_N[ENC_SIZE];                    /* Stores encoder numer. taps. */
extern int Enc_D[ENC_SIZE];                    /* Stores encoder denom. taps. */
extern int Trel_NS[NUM_STATES][NUM_INPUTS];                    /* Next state. */
extern int Trel_PS[NUM_STATES][NUM_INPUTS];                    /* Prev state. */
extern int Trel_Op[NUM_STATES][NUM_INPUTS];                       /* Outputs. */
extern int State_Inx[NUM_STATES];             /* State index for Trel_PS[][]. */
/******************************************************************************/
/*                            BCJR VARIABLES.
*******************************************************************************/
extern int Iter;                                        /* Counts iterations. */
extern double Alpha[FRAME_SIZE][NUM_STATES];                       /* Alphas. */
extern double Beta[FRAME_SIZE_P1][NUM_STATES];                      /* Betas. */
extern double Gamma_1[FRAME_SIZE][QPSK_SIZE];            /* Gamma for dec. 1. */
extern double Gamma_2[FRAME_SIZE][QPSK_SIZE];            /* Gamma for dec. 2. */
extern double Prob[FRAME_SIZE][NUM_INPUTS];            /* Data probabilities. */
extern double QProb[FRAME_SIZE][QPSK_SIZE];            /* QPSK probabilities. */
/******************************************************************************/
