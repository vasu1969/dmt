/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include "dmt44_icfunctions.h"
/******************************************************************************/
/*                    SIMULATION RUN LENGTH PARAMETER.
*******************************************************************************/
#define MAX_FRAMES 10000                         /* Length of simulation run. */
#define FRAME_SIZE 512                       /* No. of input bits in a frame. */
#define FRAME_SIZE_P1 (FRAME_SIZE+ONE)              /* No. of input bits + 1. */
#define IV_SIZE FRAME_SIZE                        /* Size of the interleaver. */
/******************************************************************************/
/*                         CONSTELLATION PARAMETERS.
*******************************************************************************/
#define BITS_PER_SYM 1                                /* Bits per tx. symbol. */
#define CONSTELL_SIZE 2                        /* Size of BPSK constellation. */
#define QPSK_SIZE 4                            /* Size of QPSK constellation. */
/******************************************************************************/
/*               MASSIVE MIMO AND RETRANSMISSION PARAMETERS.
*******************************************************************************/
#define NUM_TX 1                              /* No. of tx and rx antennas. */
#define NUM_BLKS (2*FRAME_SIZE/NUM_TX)            /* No. of blocks per frame. */
/******************************************************************************/
/*                          TRELLIS PARAMETERS.
*******************************************************************************/
#define MEM_SIZE 2                                      /* Memory of encoder. */
#define ENC_SIZE (MEM_SIZE+1)                /* Max. no. of taps for encoder. */
#define NUM_STATES 4               /* No. of states in the component trellis. */
#define NUM_INPUTS 2                          /* No. of inputs to each state. */
/******************************************************************************/
/*                  GAUSSIAN NOISE GENERATOR PARAMETERS.
*******************************************************************************/
#define SNR_B (+4.00)                                        /* SNR per bit. */
#define PN_SIZE 3                 /* Size of array which stores the PN value. */
#define NVALSIZE 4
#define URADIUS 0
#define UTHETA 1
#define GRAND_0 2
#define GRAND_1 3
/******************************************************************************/
/*                             BCJR PARAMETERS.
*******************************************************************************/
#define MAX_ITER 8                                    /* No. of iterations. */
/******************************************************************************/
/*                                PRINT TIME.
*******************************************************************************/
#define PRINT_TIME 1
#define PRINT_FRAME 250
/******************************************************************************/
/*                             CONSTANTS.
*******************************************************************************/
#define BINSIZE 16         /* Size of array to store states in binary format. */
#define TWO 2
#define ONE 1
#define ZERO 0
#define TRUE 1
#define FALSE 0
#define LEFT 0
#define RIGHT 1
#define RE 0
#define IM 1
#define MINUSONE (-1)
#define ERROR 0.00000001
#define FRAC_ZERO 0.0
#define MIN_MAG (-1000000000.0)
#define MIN_EXPO (-30.0)
#define MAX 100000000.0
/******************************************************************************/
