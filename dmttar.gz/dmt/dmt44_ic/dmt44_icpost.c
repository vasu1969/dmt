/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt44_ictype.h"
#include "dmt44_icext.h"
/******************************************************************************/
int Post_Processor()
{
 printf("\t No. of bit errors is:%d.\n\n",Ber);
 printf("\t No. of bits transmitted:%d.\n\n",FRAME_SIZE*MAX_FRAMES);
 return(0);
}
/******************************************************************************/
