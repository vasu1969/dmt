/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt43_ictype.h"
#include "dmt43_icext.h"
/******************************************************************************/
/*                   Get the symbol to be transmitted.
*******************************************************************************/
int Get_Frame()
{
 Get_Data_Bits();
 Get_Enc_Iv_Bits();
 return(0);
}
/******************************************************************************/
/*                          Get the data bits.
*******************************************************************************/
int Get_Data_Bits()
{
 int cnt,bit,enc_bit;
 double sym0,sym1;
 int rand(void);
 Enc_State=ZERO;                                /* Encoder 1 state at time 0. */
 for(cnt=ZERO;cnt<FRAME_SIZE;cnt++)
 {
  bit=Bits[cnt]=rand()&1;
  enc_bit=Trel_Op[Enc_State][bit];
  Enc_State=Trel_NS[Enc_State][bit];                   /* Get the next state. */
  sym0=Bit_Map[bit];
  sym1=Bit_Map[enc_bit];
  QPSK_Sym[cnt]=sym0+sym1*I;                         /* Re: data; Im: parity. */
 }
 Enc1_F_State=Enc_State;                         /* Final state of encoder 1. */
 return(0);
}
/******************************************************************************/
/*                   Get the interleaved and encoded bits.
*******************************************************************************/
int Get_Enc_Iv_Bits()
{
 int cnt,bit,enc_bit,iv_inx,cnt1;
 double sym0,sym2;
 Enc_State=ZERO;                                /* Encoder 2 state at time 0. */
 for(cnt=ZERO;cnt<FRAME_SIZE;cnt++)
 {
  cnt1=cnt+FRAME_SIZE;
  iv_inx=De_Iv_Map[cnt];
  bit=Bits[iv_inx];
  enc_bit=Trel_Op[Enc_State][bit];
  Enc_State=Trel_NS[Enc_State][bit];                   /* Get the next state. */
  sym0=Bit_Map[bit];
  sym2=Bit_Map[enc_bit];
  QPSK_Sym[cnt1]=sym0+sym2*I;                        /* Re: data; Im: parity. */
 }
 Enc2_F_State=Enc_State;                         /* Final state of encoder 2. */
 return(0);
}
/******************************************************************************/
/*                   Print the input bits to both encoders.
*******************************************************************************/
int Print_Input_Bits()
{
 int cnt;
 printf("\t Input bits to 1st encoder:\n\n");
 for(cnt=ZERO;cnt<FRAME_SIZE;cnt++)
  printf("\t Time:%6d Enc1 bit:%d\n",cnt,Bits[cnt]);
 printf("\n");
 return(0);
}
/******************************************************************************/
/*                            Print the symbols.
*******************************************************************************/
int Print_Symbols()
{
 int cnt;
 printf("\t Transmitted symbols:\n\n");
 for(cnt=ZERO;cnt<2*FRAME_SIZE;cnt++)
 {
  printf("\t Time:%6d Sym:%+lf\n",cnt,QPSK_Sym[cnt]);
 }
 printf("\n");
 return(0);
}
/******************************************************************************/
