/******************************************************************************/
/*   Copyright (C) 2005 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt43_ictype.h"
#include "dmt43_icext.h"
/******************************************************************************/
int Pre_Processor()
{
 Sim_Init();
 Get_BPSK_Map();
 Get_QPSK_Map();
 Get_Iv_Map();                                        /*  Random interleaver. */
 Get_Enc_Taps();
 Get_Trellis();
 Ck_Var();
 return(0);
}
/******************************************************************************/
/*                           Get encoder 1 taps.
*******************************************************************************/
int Get_Enc_Taps()
{
 Get_Enc_Numer_Taps();
 Get_Enc_Denom_Taps();
 return(0);
}
/******************************************************************************/
/* Get encoder 1 numerator taps corresponding to 1+D^2. See "Digital
 * Communications and Signal Processing" by K Vasudevan, Universities
 * Press, 2010. http://www.universitiespress.com
*******************************************************************************/
int Get_Enc_Numer_Taps()
{
 Enc_N[0]=1;
 Enc_N[1]=0;
 Enc_N[2]=1;
 return(0);
}
/******************************************************************************/
/* Get encoder 1 denominator taps corresponding to 1+D+D^2. See "Digital
 * Communications and Signal Processing" by K Vasudevan, Universities
 * Press, 2010. http://www.universitiespress.com
*******************************************************************************/
int Get_Enc_Denom_Taps()
{
 Enc_D[0]=1;
 Enc_D[1]=1;
 Enc_D[2]=1;
 return(0);
}
/******************************************************************************/
