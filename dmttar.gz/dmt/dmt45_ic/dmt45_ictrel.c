/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt45_ictype.h"
#include "dmt45_icext.h"
/******************************************************************************/
/*                          Get the trellis.
*******************************************************************************/
int Get_Trellis()
{
 int p_state,p_input;
 printf("\t Trellis:\n\n");
 Init_State_Inx();
 for(p_state=ZERO;p_state<NUM_STATES;p_state++)
 {
  for(p_input=ZERO;p_input<NUM_INPUTS;p_input++)
  {
   Get_Op(p_state,p_input);
   Get_Next_State(p_state,p_input);
  }
 }
 Print_Trellis();
 return(0);
}
/******************************************************************************/
/*                        Initialize the state index.
*******************************************************************************/
int Init_State_Inx()
{
 int p_state;
 for(p_state=ZERO;p_state<NUM_STATES;p_state++)
  State_Inx[p_state]=ZERO;
 return(0);
}
/******************************************************************************/
/*                          Get the parity bit.
*******************************************************************************/
int Get_Op(p_state,p_input)
int p_state,p_input;
{
 int bin_state[MEM_SIZE],cnt,op;
 Decimal_to_Binary(p_state,bin_state,MEM_SIZE);
 op=Get_Feedback_Bit(bin_state,p_input);
 for(cnt=ZERO;cnt<MEM_SIZE;cnt++)
  op=op^(Enc_N[cnt+ONE]*bin_state[cnt]);
 Trel_Op[p_state][p_input]=op;                     /* This is the parity bit. */
 return(0);
}
/******************************************************************************/
/*                        Get the feedback bit.
*******************************************************************************/
int Get_Feedback_Bit(bin_state,p_input)
int bin_state[],p_input;
{
 int cnt,fbit;
 fbit=p_input;
 for(cnt=ZERO;cnt<MEM_SIZE;cnt++)
  fbit=fbit^(Enc_D[cnt+ONE]*bin_state[cnt]);
 return(fbit);
}
/******************************************************************************/
/*                           Get the next state.
*******************************************************************************/
int Get_Next_State(p_state,p_input)
int p_state,p_input;
{
 int bin_state[MEM_SIZE],cnt,fbit,new_state,inx;
 Decimal_to_Binary(p_state,bin_state,MEM_SIZE);
 fbit=Get_Feedback_Bit(bin_state,p_input);
 for(cnt=(MEM_SIZE-ONE);cnt>ZERO;cnt--)
  bin_state[cnt]=bin_state[cnt-ONE];
 bin_state[ZERO]=fbit;
 Trel_NS[p_state][p_input]=new_state=Binary_to_Decimal(bin_state,MEM_SIZE);
 inx=State_Inx[new_state];
 Trel_PS[new_state][inx]=p_state;
 State_Inx[new_state]++;
 if(State_Inx[new_state] > NUM_INPUTS)
  Error_Mes(10);
 return(0);
}
/******************************************************************************/
/*                          Print the trellis.
*******************************************************************************/
int Print_Trellis()
{
 int p_state,p_input,nxt_state;
 for(p_state=ZERO;p_state<NUM_STATES;p_state++)
 {
  for(p_input=ZERO;p_input<NUM_INPUTS;p_input++)
  {
   nxt_state=Trel_NS[p_state][p_input];
   printf("\t State:%4d Input:%4d ",p_state,p_input);
   printf("Nxt. State:%4d ",Trel_NS[p_state][p_input]);
   printf("Prv. State:%4d ",Trel_PS[p_state][p_input]);
   printf("Parity:%4d\n",Trel_Op[p_state][p_input]);
  }
 }
 printf("\n");
 return(0);
}
/******************************************************************************/
