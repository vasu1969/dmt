/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt45_ictype.h"
#include "dmt45_icext.h"
/******************************************************************************/
/*                          Check the variables.
*******************************************************************************/
int Ck_Var()
{
 Ck_Tx_Constell_Size();
 Ck_Num_States();
 Ck_Num_Blks();
 Ck_Print_Time();
 return(0);
}
/******************************************************************************/
/*                Check the transmitted constellation size.
*******************************************************************************/
int Ck_Tx_Constell_Size()
{
 int cnt,pow;
 pow=1;
 for(cnt=ZERO;cnt<BITS_PER_SYM;cnt++)
  pow=pow*2;
 if(CONSTELL_SIZE != pow)
  Error_Mes(2);
 return(0);
}
/******************************************************************************/
/*                       Check the number of states.
*******************************************************************************/
int Ck_Num_States()
{
 int cnt,pow;
 pow=1;
 for(cnt=ZERO;cnt<MEM_SIZE;cnt++)
  pow=pow*2;
 if(NUM_STATES != pow)
  Error_Mes(3);
 return(0);
}
/******************************************************************************/
/*                     Check the number of blocks per frame.
*******************************************************************************/
int Ck_Num_Blks()
{
 if((FRAME_SIZE%NUM_TX) != ZERO)
  Error_Mes(9);
 return(0);
}
/******************************************************************************/
/*                         Check the print time.
*******************************************************************************/
int Ck_Print_Time()
{
 if((PRINT_TIME<ZERO) || (PRINT_TIME>(FRAME_SIZE-2)))
  Error_Mes(4);
 return(0);
}
/******************************************************************************/
