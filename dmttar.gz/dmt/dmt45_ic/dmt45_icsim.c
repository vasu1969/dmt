/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt45_ictype.h"
#include "dmt45_icext.h"
/******************************************************************************/
int Simulation()
{
 for(Frame_Cnt=ZERO;Frame_Cnt<MAX_FRAMES;Frame_Cnt++)
 {
  Get_Frame();
  for(Blk_Cnt=ZERO;Blk_Cnt<NUM_BLKS;Blk_Cnt++)
  {
   Get_Chan();
   Get_Noise();
   Get_Rx_Signal();
  }
  Receive();
 }
 return(0);
}
/******************************************************************************/
/*                         Get the channel matrix.
*******************************************************************************/
int Get_Chan()
{
 int rows,cols;
 double erand48();
 for(rows=ZERO;rows<NUM_TX;rows++)
 {
  for(cols=ZERO;cols<NUM_TX;cols++)
  {
   C1_Val[URADIUS]=erand48(C1_Store);
   C1_Val[UTHETA] =erand48(C2_Store);
   My_Gauss(C_Variance,C1_Val);
   Chan[Blk_Cnt][rows][cols]=C1_Val[GRAND_0]+C1_Val[GRAND_1]*I;
//   printf("r:%d c:%d ",rows,cols);
//   printf("ch:%lf+I*%lf\n",creal(Chan[rows][cols]),cimag(Chan[rows][cols]));
  }
 }
 return(0);
}
/******************************************************************************/
/*                        Add white Gaussian noise.
*******************************************************************************/
int Get_Noise()
{
 int cnt;
 double erand48();
 for(cnt=ZERO;cnt<NUM_TX;cnt++)
 {
  N1_Val[URADIUS]=erand48(N1_Store);
  N1_Val[UTHETA]= erand48(N2_Store);
  My_Gauss(Variance,N1_Val);
  Noise[cnt]=N1_Val[GRAND_0]+N1_Val[GRAND_1]*I;
 }
 return(0);
}
/******************************************************************************/
/*                        Get the received signal.
*******************************************************************************/
int Get_Rx_Signal()
{
 int cnt,cnt1,cnt2,cnt3;
 for(cnt=ZERO;cnt<NUM_TX;cnt++)
 {
  cnt2=Blk_Cnt*NUM_TX+cnt;
  Rx_Sig[cnt2]=0.0+0.0*I;
  for(cnt1=ZERO;cnt1<NUM_TX;cnt1++)
  {
   cnt3=Blk_Cnt*NUM_TX+cnt1;
   Rx_Sig[cnt2]=Rx_Sig[cnt2]+Chan[Blk_Cnt][cnt][cnt1]*QPSK_Sym[cnt3];
  }
  Rx_Sig[cnt2]=Rx_Sig[cnt2]+Noise[cnt];
 }
 return(0);
}
/******************************************************************************/
/*                            Receiver routines.
*******************************************************************************/
int Receive()
{
 Get_HD();
 Get_Int_Vec();
 Get_Gamma();
 Init_App();
 Bcjr();
 Get_Bit_Errors_Dec1();
 return(0);
}
/******************************************************************************/
/*                             Get hard decisions.
*******************************************************************************/
int Get_HD()
{
 int cnt,sym_cnt,hd_sym_num,bcnt,cnt1;
 double dist,min_dist;
 for(bcnt=ZERO;bcnt<NUM_BLKS;bcnt++)
 {
  for(cnt=ZERO;cnt<NUM_TX;cnt++)
  {
   min_dist=MAX;
   cnt1=bcnt*NUM_TX+cnt;
   for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
   {
    dist=cabs(Rx_Sig[cnt1]-QPSK_Map[sym_cnt]*Chan[bcnt][cnt][cnt]);
    if(dist < min_dist)
    {
     min_dist=dist;
     hd_sym_num=sym_cnt;
    }
   }
   HD_QPSK[cnt1]=QPSK_Map[hd_sym_num];                       /* Practical HD. */
//  HD_QPSK[cnt]=QPSK_Sym[cnt];                                  /* Ideal HD. */
  }
 }
 return(0);
}
/******************************************************************************/
/*                       Get the interference vector.
*******************************************************************************/
int Get_Int_Vec()
{
 int cnt,cnt1,cnt2,cnt3,bcnt;
 for(bcnt=ZERO;bcnt<NUM_BLKS;bcnt++)
 {
  for(cnt=ZERO;cnt<NUM_TX;cnt++)
  {
   cnt1=bcnt*NUM_TX+cnt;
   Int_Vec[cnt1]=0.0+0.0*I;
   for(cnt2=ZERO;cnt2<NUM_TX;cnt2++)
   {
    cnt3=bcnt*NUM_TX+cnt2;
    if(cnt != cnt2)
     Int_Vec[cnt1]=Int_Vec[cnt1]+Chan[bcnt][cnt][cnt2]*HD_QPSK[cnt3];
   }
  }
 }
 return(0);
}
/******************************************************************************/
/*                      Get gamma for decoder 1 and 2.
*******************************************************************************/
int Get_Gamma()
{
 int time,sym_cnt,time1,bcnt,cnt1;
 double x,y,max1,max2;
 double complex sym,tchan;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  time1=time+FRAME_SIZE;
  max1=max2=MIN_MAG;
  for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  {
   sym=QPSK_Map[sym_cnt];
   x=cabs(sym*Vec_Diag[time] +Int_Vec[time]  -Vec_Rx_Sig[time]);
   y=cabs(sym*Vec_Diag[time1]+Int_Vec[time1] -Vec_Rx_Sig[time1]);
   Gamma_1[time][sym_cnt]= -x*x*Inv_Int_Var;
   Gamma_2[time][sym_cnt]= -y*y*Inv_Int_Var;
   if(Gamma_1[time][sym_cnt] > max1)
    max1=Gamma_1[time][sym_cnt];
   if(Gamma_2[time][sym_cnt] > max2)
    max2=Gamma_2[time][sym_cnt];
  }
//  printf("init gamma ti:%d ",time);
//  printf("max1:%lf\n",max1);
  Get_Norm_Gamma(time,max1,max2);
 }
 return(0);
}
/******************************************************************************/
/*              Get the normalized gamma for decoder 1 and 2.
*******************************************************************************/
int Get_Norm_Gamma(time,max1,max2)
int time;
double max1,max2;
{
 int sym_cnt;
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
 {
//  printf("bnorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=Gamma_1[time][sym_cnt]-max1;
  Gamma_2[time][sym_cnt]=Gamma_2[time][sym_cnt]-max2;
  if(Gamma_1[time][sym_cnt] < MIN_EXPO)
   Gamma_1[time][sym_cnt]=MIN_EXPO;
  if(Gamma_2[time][sym_cnt] < MIN_EXPO)
   Gamma_2[time][sym_cnt]=MIN_EXPO;
//  printf("anorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=exp(Gamma_1[time][sym_cnt]);
  Gamma_2[time][sym_cnt]=exp(Gamma_2[time][sym_cnt]);
 }
 return(0);
}
/******************************************************************************/
/*                Initialize the a posteriori probabilities.
*******************************************************************************/
int Init_App()
{
 int time,input;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  for(input=ZERO;input<NUM_INPUTS;input++)
   Prob[time][input]=0.5;
 }
 return(0);
}
/******************************************************************************/
/*                          The BCJR algorithm.
*******************************************************************************/
int Bcjr()
{
 for(Iter=ZERO;Iter<MAX_ITER;Iter++)
 {
  Dec2_Process();
  Get_HD_from_Prob(1);
  Get_Int_Vec_Dec2();
  Get_Gamma2();
  Dec1_Process();
  Get_HD_from_Prob(0);
  Get_Int_Vec_Dec1();
  Get_Gamma1();
 }
 return(0);
}
/******************************************************************************/
/*                 Get hard decisions from the probabilities.
*******************************************************************************/
int Get_HD_from_Prob(num)
int num;
{
 int cnt,sym_cnt,hd_sym_num;
 double max;
 for(cnt=ZERO;cnt<FRAME_SIZE;cnt++)
 {
  max=MIN_MAG;
  for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  {
   if(QProb[cnt][sym_cnt] > max)
   {
    max=QProb[cnt][sym_cnt];
    hd_sym_num=sym_cnt;
   }
  }
  HD_QPSK[num*FRAME_SIZE+cnt]=QPSK_Map[hd_sym_num];        /* Practical HD. */
//  HD_QPSK[num*FRAME_SIZE+cnt]=QPSK_Sym[num*FRAME_SIZE+cnt];    /* Ideal HD. */
 }
 return(0);
}
/******************************************************************************/
/*                 Get the interference vector for decoder 2.
*******************************************************************************/
int Get_Int_Vec_Dec2()
{
 int cnt,cnt1,cnt2,cnt3,bcnt;
 for(bcnt=NUM_BLKS/2;bcnt<NUM_BLKS;bcnt++)
 {
  for(cnt=ZERO;cnt<NUM_TX;cnt++)
  {
   cnt1=bcnt*NUM_TX+cnt;
   Int_Vec[cnt1]=0.0+0.0*I;
   for(cnt2=ZERO;cnt2<NUM_TX;cnt2++)
   {
    cnt3=bcnt*NUM_TX+cnt2;
    Int_Vec[cnt1]=Int_Vec[cnt1]+CHC[bcnt][cnt][cnt2]*HD_QPSK[cnt3];
   }
  }
 }
 return(0);
}
/******************************************************************************/
/*                          Get gamma for decoder 2.
*******************************************************************************/
int Get_Gamma2()
{
 int time,sym_cnt,time1;
 double y,max2;
 double complex sym;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  time1=time+FRAME_SIZE;
  max2=MIN_MAG;
  for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  {
   sym=QPSK_Map[sym_cnt];
   y=cabs(sym*Vec_Diag[time1]+Int_Vec[time1] -Vec_Rx_Sig[time1]);
   Gamma_2[time][sym_cnt]= -y*y*Inv_Int_Var;
   if(Gamma_2[time][sym_cnt] > max2)
    max2=Gamma_2[time][sym_cnt];
  }
//  printf("init gamma ti:%d ",time);
//  printf("max1:%lf\n",max1);
  Get_Norm_Gamma2(time,max2);
 }
 return(0);
}
/******************************************************************************/
/*                  Get the normalized gamma for decoder 2.
*******************************************************************************/
int Get_Norm_Gamma2(time,max2)
int time;
double max2;
{
 int sym_cnt;
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
 {
//  printf("bnorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_2[time][sym_cnt]=Gamma_2[time][sym_cnt]-max2;
  if(Gamma_2[time][sym_cnt] < MIN_EXPO)
   Gamma_2[time][sym_cnt]=MIN_EXPO;
//  printf("anorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_2[time][sym_cnt]=exp(Gamma_2[time][sym_cnt]);
 }
 return(0);
}
/******************************************************************************/
/*                Get the interference vector for decoder 1.
*******************************************************************************/
int Get_Int_Vec_Dec1()
{
 int cnt,cnt1,cnt2,cnt3,bcnt;
 for(bcnt=ZERO;bcnt<NUM_BLKS/2;bcnt++)
 {
  for(cnt=ZERO;cnt<NUM_TX;cnt++)
  {
   cnt1=bcnt*NUM_TX+cnt;
   Int_Vec[cnt1]=0.0+0.0*I;
   for(cnt2=ZERO;cnt2<NUM_TX;cnt2++)
   {
    cnt3=bcnt*NUM_TX+cnt2;
    Int_Vec[cnt1]=Int_Vec[cnt1]+CHC[bcnt][cnt][cnt2]*HD_QPSK[cnt3];
   }
  }
 }
 return(0);
}
/******************************************************************************/
/*                          Get gamma for decoder 1.
*******************************************************************************/
int Get_Gamma1()
{
 int time,sym_cnt;
 double x,max1;
 double complex sym;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  max1=MIN_MAG;
  for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  {
   sym=QPSK_Map[sym_cnt];
   x=cabs(sym*Vec_Diag[time] +Int_Vec[time]  -Vec_Rx_Sig[time]);
   Gamma_1[time][sym_cnt]= -x*x*Inv_Int_Var;
   if(Gamma_1[time][sym_cnt] > max1)
    max1=Gamma_1[time][sym_cnt];
  }
//  printf("init gamma ti:%d ",time);
//  printf("max1:%lf\n",max1);
  Get_Norm_Gamma1(time,max1);
 }
 return(0);
}
/******************************************************************************/
/*                  Get the normalized gamma for decoder 1.
*******************************************************************************/
int Get_Norm_Gamma1(time,max1)
int time;
double max1;
{
 int sym_cnt;
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
 {
//  printf("bnorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=Gamma_1[time][sym_cnt]-max1;
  if(Gamma_1[time][sym_cnt] < MIN_EXPO)
   Gamma_1[time][sym_cnt]=MIN_EXPO;
//  printf("anorm ti:%d scnt:%d ",time,sym_cnt);
//  printf("max1:%lf G1:%lf\n",max1,Gamma_1[time][sym_cnt]);
  Gamma_1[time][sym_cnt]=exp(Gamma_1[time][sym_cnt]);
 }
 return(0);
}
/******************************************************************************/
/*    Finally compute the number of bit errors in the frame from decoder1.
*******************************************************************************/
int Get_Bit_Errors_Dec1()
{
 int time,detected_bit,act_bit;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  detected_bit=ONE;
  if(Prob[time][ZERO] > Prob[time][ONE])
   detected_bit=ZERO;
  act_bit=Bits[time];
  if(detected_bit != Bits[time])
   Ber++;
 }
 return(0);
}
/******************************************************************************/
/*                       Print out the probabilities.
*******************************************************************************/
int Print_Prob()
{
 int time,act_bit;
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  act_bit=Bits[time];
  printf("Print prob Frame:%d time:%d tx bit:%d ",Frame_Cnt,time,act_bit);
  printf("Prob 0:%lf  ",Prob[time][0]);
  printf("Prob 1:%lf\n",Prob[time][1]);
 }
 return(0);
}
/******************************************************************************/
