/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt45_ictype.h"
#include "dmt45_icext.h"
/******************************************************************************/
/*                     Do processing for decoder 1.
*******************************************************************************/
int Dec1_Process()
{
 Init_Alpha_Beta_Dec1();
 Compute_Alpha_Beta_Dec1();
 if(Iter < (MAX_ITER-ONE))
  Compute_APPLes_Dec1();
 else if(Iter == (MAX_ITER-ONE))
  Compute_Final_APPs_Dec1();
 return(0);
}
/******************************************************************************/
/*                          Initialize alpha and beta.
*******************************************************************************/
int Init_Alpha_Beta_Dec1()
{
 int state;
 for(state=ZERO;state<NUM_STATES;state++)
  Alpha[ZERO][state]=Beta[FRAME_SIZE][state]=1.0;
 return(0);
}
/******************************************************************************/
/*                   Compute the alpha and beta values.
*******************************************************************************/
int Compute_Alpha_Beta_Dec1()
{
 int time,state;
 for(time=ZERO;time<=FRAME_SIZE-TWO;time++)
 {
  for(state=ZERO;state<NUM_STATES;state++)
   Get_New_Alpha_Beta_Dec1(time,state);
  Normalize_Alpha_Beta(time);
 }
 return(0);
}
/******************************************************************************/
/*      Compute the new alpha and beta values for a given state and time.
*******************************************************************************/
int Get_New_Alpha_Beta_Dec1(time,state)
int time,state;
{
 int input,prv_st,nxt_st,opa,opb,syma,symb;
 double gea,geb,proba,probb,prv_alpha,nxt_beta,alpha,beta;
 alpha=beta=0.0;
 for(input=ZERO;input<NUM_INPUTS;input++)                       /* Data bits. */
 {
  prv_st=Trel_PS[state][input];
  nxt_st=Trel_NS[state][input];
  opa=Trel_Op[prv_st][input];                             /* Get encoded bit. */
  opb=Trel_Op[state][input];                              /* Get encoded bit. */
  syma=2*input+opa;                                          /* QPSK sym num. */
  symb=2*input+opb;                                          /* QPSK sym num. */
  gea=Gamma_1[time][syma];                                        /* Gamma_a. */
  geb=Gamma_1[FRAME_SIZE-ONE-time][symb];                         /* Gamma_b. */
  proba=Prob[time][input];
  probb=Prob[FRAME_SIZE-ONE-time][input];
  prv_alpha=Alpha[time][prv_st];
  nxt_beta=Beta[FRAME_SIZE-ONE-time+ONE][nxt_st];
  alpha=alpha+gea*proba*prv_alpha;
  beta=beta+geb*probb*nxt_beta;
 }
 Alpha[time+ONE][state]=alpha;
 Beta[FRAME_SIZE-ONE-time][state]=beta;
 return(0);
}
/******************************************************************************/
/*           Compute the APPs due to extrinsic information alone.
*******************************************************************************/
int Compute_APPLes_Dec1()
{
 int time;
 double app[NUM_INPUTS],qapp[QPSK_SIZE];
 for(time=ZERO;time<FRAME_SIZE;time++)
 {
  Get_APPLe_Dec1(time,app,qapp);
  Get_Prob_Dec1(time,app,qapp);
 }
 return(0);
}
/******************************************************************************/
/*                Get the a posteriori probability of +1 and -1.
*******************************************************************************/
int Get_APPLe_Dec1(time,app,qapp)
int time;
double app[],qapp[];
{
 int state,input,nxt_state,op,sym_cnt;
 double ge,prv_alpha,nxt_beta;
 app[ZERO]=app[ONE]=0.0;
 qapp[0]=qapp[1]=qapp[2]=qapp[3]=0.0;
 for(state=ZERO;state<NUM_STATES;state++)
 {
  for(input=ZERO;input<NUM_INPUTS;input++)
  {
   nxt_state=Trel_NS[state][input];                          /* 0 maps to +1. */
   op=Trel_Op[state][input];
   sym_cnt=2*input+op;
   ge=Gamma_1[time][sym_cnt];                                     /* Gamma_1. */
   prv_alpha=Alpha[time][state];
   nxt_beta=Beta[time+ONE][nxt_state];
   app[input]=app[input]+ge*prv_alpha*nxt_beta;
   qapp[sym_cnt]=qapp[sym_cnt]+ge*prv_alpha*nxt_beta*Prob[time][input];
//   qapp[sym_cnt]=qapp[sym_cnt]+ge*prv_alpha*nxt_beta;
  }
 }
 return(0);
}
/******************************************************************************/
/*                     Get the normalized probabilities.
*******************************************************************************/
int Get_Prob_Dec1(time,app,qapp)
int time;
double app[],qapp[];
{
 int input,sym_cnt;
 double sum,qsum;
 sum=qsum=0.0;
 for(input=ZERO;input<NUM_INPUTS;input++)
  sum=sum+app[input];
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  qsum=qsum+qapp[sym_cnt];
 for(input=ZERO;input<NUM_INPUTS;input++)
  Prob[time][input]=app[input]/sum;
 for(sym_cnt=ZERO;sym_cnt<QPSK_SIZE;sym_cnt++)
  QProb[time][sym_cnt]=qapp[sym_cnt]/qsum;
 return(0);
}
/******************************************************************************/
