/******************************************************************************/
/*   Copyright (C) 2017 K. Vasudevan. Indian Institute of Technology Kanpur.  */
/*   All Rights Reserved.                                                     */
/******************************************************************************/
#include "dmt45_ictype.h"
#include "dmt45_icext.h"
/******************************************************************************/
/*                         Convert decimal to binary.
*******************************************************************************/
int Decimal_to_Binary(num,array,array_size)
int num,array[],array_size;
{
 int cnt;
 for(cnt=ZERO;cnt<array_size;cnt++)
  array[cnt]=ZERO;
 cnt=ZERO;
 while(num>ZERO)
 {
  if(cnt == array_size)
   Error_Mes(1);
  array[cnt]=num&1;
  num=num>>1;
  cnt++;
 }
 return(0);
}
/******************************************************************************/
/*                    Convert binary array to decimal.
*******************************************************************************/
int Binary_to_Decimal(array,size)
int array[],size;
{
 int cnt,pow,sum;
 sum=ZERO;
 pow=1;
 for(cnt=ZERO;cnt<size;cnt++)
 {
  sum=sum+pow*array[cnt];
  pow=pow<<1;
 }
 return(sum);
}
/******************************************************************************/
/*                        Normalize the alpha values.
*******************************************************************************/
int Normalize_Alpha_Beta(time)
int time;
{
 int state;
 double suma,sumb;
 suma=sumb=0.0;
 for(state=ZERO;state<NUM_STATES;state++)
 {
  suma=suma+Alpha[time+ONE][state];
  sumb=sumb+Beta[FRAME_SIZE-ONE-time][state];
 }
 for(state=ZERO;state<NUM_STATES;state++)
 {
  Alpha[time+ONE][state]=Alpha[time+ONE][state]/suma;
  Beta[FRAME_SIZE-ONE-time][state]=Beta[FRAME_SIZE-ONE-time][state]/sumb;
 }
 return(0);
}
/******************************************************************************/
/*                    Print the alpha and beta values.
*******************************************************************************/
int Print_Alpha_Beta()
{
 int cnt;
 for(cnt=ZERO;cnt<NUM_STATES;cnt++)
 {
  printf("\t Iter:%d State:%d Alpha:%lf ",Iter,cnt,Alpha[PRINT_TIME][cnt]);
  printf(" Beta:%lf\n",Beta[PRINT_TIME+ONE][cnt]);
 }
 return(0);
}
/******************************************************************************/
/*                      Initialize the coefficients.
*******************************************************************************/
int Init_Coef(coef)
double coef[TWO][TWO];
{
 int cnt1,cnt2;
 for(cnt1=ZERO;cnt1<TWO;cnt1++)
 {
  for(cnt2=ZERO;cnt2<TWO;cnt2++)
   coef[cnt1][cnt2]=0.0;
 }
 return(0);
}
/******************************************************************************/
/*  Convert uniform random variables to gaussian random variables. Refer to
 *  DSP by Proakis and Manolakis.
*******************************************************************************/
int My_Gauss(tvar,tnarry)
double tvar,tnarry[];
{
 double r,theta;
 r= -2.0*tvar*log(1.0-tnarry[URADIUS]);
 if(r < FRAC_ZERO)
  Error_Mes(10);
 r=sqrt(r);
 theta=2.0*M_PI*tnarry[UTHETA];
 tnarry[GRAND_0]=r*cos(theta);
 tnarry[GRAND_1]=r*sin(theta);
 return(0);
}
/******************************************************************************/
/*                 Check for memory allocation failure.
*******************************************************************************/
int Ck_Calloc(tmp)
void *tmp;
{
 if(tmp==NULL)
  Error_Mes(5);
 return(0);
}
/******************************************************************************/
/*                             Error message.
*******************************************************************************/
int Error_Mes(num)
int num;
{
 fprintf(stdout,"\t Simulation error. Exiting with code %d.\n\n",num);
 exit(num);
 return(0);
}
/******************************************************************************/
