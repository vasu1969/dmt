//driver: sciw release sequential 
/*------------------------------------------------------------------ -*- C++ -*-
 *
 * (c) HPC Project - 2010-2012 - All rights reserved
 * (c) SILKAN      - 2012-2017
 *
 * COLD 2.5.1 (1ae9408)
 *
 */

#define _CRT_SCIW_COMPILATION_

#include "api_scilab.h"
#include "crt_sciw.h"

/* -------------------------------------------------------------------------- */

template < typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7, typename A8 >
void Dec1_Process_0(crt::Array<double,2,A1>& _u_Prob, const crt::Array<double,2,A2>& _tmpcall0, const int& _u_DATA_SIZE, const int& _u_NUM_STATES, const crt::Array<int,2,A3>& _u_Ga_Inx, const crt::Array<int,2,A4>& _u_Gb_Inx, const crt::Array<int,2,A5>& _u_P_Ip, const crt::Array<int,2,A6>& _u_P_State, const crt::Array<int,2,A7>& _u_N_State, const crt::Array<double,2,A8>& _u_My_Gamma1);


/* -------------------------------------------------------------------------- */


template < typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7, typename A8 >
void Dec1_Process_0(crt::Array<double,2,A1>& _u_Prob, const crt::Array<double,2,A2>& _tmpcall0, const int& _u_DATA_SIZE, const int& _u_NUM_STATES, const crt::Array<int,2,A3>& _u_Ga_Inx, const crt::Array<int,2,A4>& _u_Gb_Inx, const crt::Array<int,2,A5>& _u_P_Ip, const crt::Array<int,2,A6>& _u_P_State, const crt::Array<int,2,A7>& _u_N_State, const crt::Array<double,2,A8>& _u_My_Gamma1)
{
  _u_Prob = _tmpcall0;
  /* ****************************************************************************** */
  /*  Initialize alpha and beta. */
  /* ****************************************************************************** */
  crt::Array<double,2,crt::heap_allocator> _u_my_alpha(crt::ARRAY,_u_NUM_STATES,_u_DATA_SIZE);
  int _tmpell29;
  _tmpell29 = (_u_NUM_STATES*_u_DATA_SIZE);
  {
    crt::__resize(_u_my_alpha,_u_NUM_STATES,_u_DATA_SIZE);
    int __iti;
    for (__iti = 1;__iti <= _tmpell29;__iti++) {
      _u_my_alpha.at((__iti-1)) = 0;
    }
  }
  crt::Array<double,2,crt::heap_allocator> _u_my_beta(crt::ARRAY,_u_NUM_STATES,(_u_DATA_SIZE+1));
  int _tmpell30;
  _tmpell30 = (_u_NUM_STATES*(_u_DATA_SIZE+1));
  {
    crt::__resize(_u_my_beta,_u_NUM_STATES,(_u_DATA_SIZE+1));
    int __iti;
    for (__iti = 1;__iti <= _tmpell30;__iti++) {
      _u_my_beta.at((__iti-1)) = 0;
    }
  }
  {
    int __iti;
    for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
      _u_my_alpha.at((__iti-1),0) = (double)1;
    }
  }
  {
    int __iti;
    for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
      _u_my_beta.at((__iti-1),((_u_DATA_SIZE+1)-1)) = (double)1;
    }
  }
  /* ****************************************************************************** */
  /*  Compute alpha and beta for decoder 1. */
  /* ****************************************************************************** */
  int _u_time;
  for (int __time = 1; __time <= (_u_DATA_SIZE-1); ++__time) {
    _u_time = __time;
    /* ****************************************************************************** */
    /*  Alpha beta recursion. */
    /* ****************************************************************************** */
    /*   for state=1:NUM_STATES */
    /*    t_alpha=0.0; */
    /*    t_beta=0.0; */
    /*    for ip=1:NUM_INPUTS */
    /*     prv_st=P_State(state,ip); */
    /*     nxt_st=N_State(state,ip); */
    /*     ipa=P_Ip(state,ip);                          // Input in the form of 1, 2. */
    /*     opa=Op(prv_st,ipa);                    // Encoded bit in the form of 0, 1. */
    /*     opb=Op(state,ip);                      // Encoded bit in the form of 0, 1. */
    /*     inxa=2*(ipa-1)+opa+1;                                    // Range: 1 to 4. */
    /*     inxb=2*(ip-1)+opb+1;                                     // Range: 1 to 4. */
    /*     ga=My_Gamma1(inxa,time); */
    /*     gb=My_Gamma1(inxb,DATA_SIZE+1-time); */
    /*     proba=Prob(ipa,time); */
    /*     probb=Prob(ip,DATA_SIZE+1-time); */
    /*     prv_alpha=my_alpha(prv_st,time); */
    /*     nxt_beta=my_beta(nxt_st,DATA_SIZE+2-time); */
    /*     t_alpha=t_alpha+ga*proba*prv_alpha; */
    /*     t_beta=t_beta+gb*probb*nxt_beta; */
    /*    end */
    /*    my_alpha(state,time+1)=t_alpha; */
    /*    my_beta(state,DATA_SIZE+1-time)=t_beta; */
    /*   end */
    /* ****************************************************************************** */
    /*  Faster alpha beta recursion. */
    /* ****************************************************************************** */
    crt::Array<double,2> _tmpao1(_u_P_State._d[0],1);
    crt::Array<int,2> _tmpxx9(_u_P_State._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_State._d[0];__iti++) {
        _tmpxx9[(__iti-1)] = _u_P_State[(__iti-1)];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_State._d[0];__iti++) {
        _tmpao1[(__iti-1)] = _u_my_alpha[((_tmpxx9[(__iti-1)]-1)+((_u_time-1)*_u_my_alpha._d[0]))];
      }
    }
    crt::Array<double,2> _tmpao2(_u_P_State._d[0],1);
    crt::Array<int,2> _tmpxx10(_u_P_State._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_State._d[0];__iti++) {
        _tmpxx10[(__iti-1)] = _u_P_State[((__iti-1)+(1*_u_P_State._d[0]))];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_State._d[0];__iti++) {
        _tmpao2[(__iti-1)] = _u_my_alpha[((_tmpxx10[(__iti-1)]-1)+((_u_time-1)*_u_my_alpha._d[0]))];
      }
    }
    crt::Array<int,2> _tmpxx11(_u_Ga_Inx._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_Ga_Inx._d[0];__iti++) {
        _tmpxx11[(__iti-1)] = _u_Ga_Inx[(__iti-1)];
      }
    }
    crt::Array<int,2> _tmpxx12(_u_P_Ip._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_Ip._d[0];__iti++) {
        _tmpxx12[(__iti-1)] = _u_P_Ip[(__iti-1)];
      }
    }
    crt::Array<int,2> _tmpxx13(_u_Ga_Inx._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_Ga_Inx._d[0];__iti++) {
        _tmpxx13[(__iti-1)] = _u_Ga_Inx[((__iti-1)+(1*_u_Ga_Inx._d[0]))];
      }
    }
    crt::Array<int,2> _tmpxx14(_u_P_Ip._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_P_Ip._d[0];__iti++) {
        _tmpxx14[(__iti-1)] = _u_P_Ip[((__iti-1)+(1*_u_P_Ip._d[0]))];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
        _u_my_alpha.at((__iti-1),((_u_time+1)-1)) = (((_tmpao1[(__iti-1)]*_u_My_Gamma1[((_tmpxx11[(__iti-1)]-1)+((_u_time-1)*_u_My_Gamma1._d[0]))])*_u_Prob[((_tmpxx12[(__iti-1)]-1)+((_u_time-1)*_u_Prob._d[0]))])+((_tmpao2[(__iti-1)]*_u_My_Gamma1[((_tmpxx13[(__iti-1)]-1)+((_u_time-1)*_u_My_Gamma1._d[0]))])*_u_Prob[((_tmpxx14[(__iti-1)]-1)+((_u_time-1)*_u_Prob._d[0]))]));
      }
    }
    crt::Array<double,2> _tmpao3(_u_N_State._d[0],1);
    crt::Array<int,2> _tmpxx15(_u_N_State._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
        _tmpxx15[(__iti-1)] = _u_N_State[(__iti-1)];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
        _tmpao3[(__iti-1)] = _u_my_beta[((_tmpxx15[(__iti-1)]-1)+((((_u_DATA_SIZE+2)-_u_time)-1)*_u_my_beta._d[0]))];
      }
    }
    crt::Array<double,2> _tmpao4(_u_N_State._d[0],1);
    crt::Array<int,2> _tmpxx16(_u_N_State._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
        _tmpxx16[(__iti-1)] = _u_N_State[((__iti-1)+(1*_u_N_State._d[0]))];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
        _tmpao4[(__iti-1)] = _u_my_beta[((_tmpxx16[(__iti-1)]-1)+((((_u_DATA_SIZE+2)-_u_time)-1)*_u_my_beta._d[0]))];
      }
    }
    crt::Array<int,2> _tmpxx17(_u_Gb_Inx._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_Gb_Inx._d[0];__iti++) {
        _tmpxx17[(__iti-1)] = _u_Gb_Inx[(__iti-1)];
      }
    }
    crt::Array<int,2> _tmpxx18(_u_Gb_Inx._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_Gb_Inx._d[0];__iti++) {
        _tmpxx18[(__iti-1)] = _u_Gb_Inx[((__iti-1)+(1*_u_Gb_Inx._d[0]))];
      }
    }
    {
      int __iti;
      for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
        _u_my_beta.at((__iti-1),(((_u_DATA_SIZE+1)-_u_time)-1)) = (((_tmpao3[(__iti-1)]*_u_My_Gamma1[((_tmpxx17[(__iti-1)]-1)+((((_u_DATA_SIZE+1)-_u_time)-1)*_u_My_Gamma1._d[0]))])*_u_Prob[((((_u_DATA_SIZE+1)-_u_time)-1)*_u_Prob._d[0])])+((_tmpao4[(__iti-1)]*_u_My_Gamma1[((_tmpxx18[(__iti-1)]-1)+((((_u_DATA_SIZE+1)-_u_time)-1)*_u_My_Gamma1._d[0]))])*_u_Prob[(1+((((_u_DATA_SIZE+1)-_u_time)-1)*_u_Prob._d[0]))]));
      }
    }
    /* ****************************************************************************** */
    /*   [my_alpha,my_beta]=Normalize_Alpha_Beta(my_alpha,my_beta,time); */
    /* ****************************************************************************** */
    crt::Array<double,2> _tmpao5(_u_my_alpha._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_my_alpha._d[0];__iti++) {
        _tmpao5[(__iti-1)] = _u_my_alpha[((__iti-1)+(((_u_time+1)-1)*_u_my_alpha._d[0]))];
      }
    }
    crt::Array<double,2> _tmpao6(_u_my_alpha._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_my_alpha._d[0];__iti++) {
        _tmpao6[(__iti-1)] = _u_my_alpha[((__iti-1)+(((_u_time+1)-1)*_u_my_alpha._d[0]))];
      }
    }
    double _tmpxx19;
    _tmpxx19 = crt::sum(_tmpao6);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
        _u_my_alpha.at((__iti-1),((_u_time+1)-1)) = (_tmpao5[(__iti-1)] / _tmpxx19);
      }
    }
    crt::Array<double,2> _tmpao7(_u_my_beta._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_my_beta._d[0];__iti++) {
        _tmpao7[(__iti-1)] = _u_my_beta[((__iti-1)+((((_u_DATA_SIZE+1)-_u_time)-1)*_u_my_beta._d[0]))];
      }
    }
    crt::Array<double,2> _tmpao8(_u_my_beta._d[0],1);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_my_beta._d[0];__iti++) {
        _tmpao8[(__iti-1)] = _u_my_beta[((__iti-1)+((((_u_DATA_SIZE+1)-_u_time)-1)*_u_my_beta._d[0]))];
      }
    }
    double _tmpxx20;
    _tmpxx20 = crt::sum(_tmpao8);
    {
      int __iti;
      for (__iti = 1;__iti <= _u_NUM_STATES;__iti++) {
        _u_my_beta.at((__iti-1),(((_u_DATA_SIZE+1)-_u_time)-1)) = (_tmpao7[(__iti-1)] / _tmpxx20);
      }
    }
  }
  /* ****************************************************************************** */
  /*  Compute the a posteriori probabilities (APPs). */
  /* ****************************************************************************** */
  /*  Slow version. */
  /* ****************************************************************************** */
  /*  for time=1:DATA_SIZE */
  /*   app(1)=0.0; */
  /*   app(2)=0.0; */
  /*   for state=1:NUM_STATES */
  /*    for ip=1:NUM_INPUTS */
  /*     nxt_state=N_State(state,ip); */
  /*     op=Op(state,ip); */
  /*     inx=2*(ip-1)+op+1; */
  /*     ge=My_Gamma1(inx,time); */
  /*     prv_alpha=my_alpha(state,time); */
  /*     nxt_beta=my_beta(nxt_state,time+1); */
  /*     app(ip)=app(ip)+ge*prv_alpha*nxt_beta; */
  /*    end */
  /*   end */
  /*   my_sum=0.0; */
  /*   for ip=1:NUM_INPUTS */
  /*    my_sum=my_sum+app(ip); */
  /*   end */
  /*   for ip=1:NUM_INPUTS */
  /*    Prob(ip,time)=app(ip)/my_sum; */
  /*   end */
  /*  end */
  /* ****************************************************************************** */
  /*  Faster version to compute APPs. */
  /* ****************************************************************************** */
  crt::Array<int,2> _tmpxx21(_u_N_State._d[0],1);
  {
    int __iti;
    for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
      _tmpxx21[(__iti-1)] = _u_N_State[(__iti-1)];
    }
  }
  crt::Array<int,2> _tmpxx22(_u_Gb_Inx._d[0],1);
  {
    int __iti;
    for (__iti = 1;__iti <= _u_Gb_Inx._d[0];__iti++) {
      _tmpxx22[(__iti-1)] = _u_Gb_Inx[(__iti-1)];
    }
  }
  crt::Array<double,2> _tmpxx23(_u_my_alpha._d[0],_u_my_alpha._d[1]);
  {
    int __itj;
    int __itji;
    int __iti;
    __itji = 2;
    for (__itj = 1;__itj <= _u_my_alpha._d[1];__itj++) {
      for (__iti = 1;__iti <= _u_my_alpha._d[0];__iti++) {
        _tmpxx23[((__iti-1)+((__itj-1)*_u_my_alpha._d[0]))] = ((_u_my_alpha[((__iti-1)+((__itj-1)*_u_my_alpha._d[0]))]*_u_my_beta[((_tmpxx21[(__iti-1)]-1)+((__itji-1)*_u_my_beta._d[0]))])*_u_My_Gamma1[((_tmpxx22[(__iti-1)]-1)+((__itj-1)*_u_My_Gamma1._d[0]))]);
      }
      __itji++;
    }
  }
  crt::Array<double,2> _tmpxx24(1,_u_my_alpha._d[1]);
  crt::sum(_tmpxx24,_tmpxx23,"r");
  {
    int __iti;
    for (__iti = 1;__iti <= _tmpcall0._d[1];__iti++) {
      _u_Prob.at(0,(__iti-1)) = _tmpxx24[(__iti-1)];
    }
  }
  crt::Array<int,2> _tmpxx25(_u_N_State._d[0],1);
  {
    int __iti;
    for (__iti = 1;__iti <= _u_N_State._d[0];__iti++) {
      _tmpxx25[(__iti-1)] = _u_N_State[((__iti-1)+(1*_u_N_State._d[0]))];
    }
  }
  crt::Array<int,2> _tmpxx26(_u_Gb_Inx._d[0],1);
  {
    int __iti;
    for (__iti = 1;__iti <= _u_Gb_Inx._d[0];__iti++) {
      _tmpxx26[(__iti-1)] = _u_Gb_Inx[((__iti-1)+(1*_u_Gb_Inx._d[0]))];
    }
  }
  crt::Array<double,2> _tmpxx27(_u_my_alpha._d[0],_u_my_alpha._d[1]);
  {
    int __itj;
    int __itji;
    int __iti;
    __itji = 2;
    for (__itj = 1;__itj <= _u_my_alpha._d[1];__itj++) {
      for (__iti = 1;__iti <= _u_my_alpha._d[0];__iti++) {
        _tmpxx27[((__iti-1)+((__itj-1)*_u_my_alpha._d[0]))] = ((_u_my_alpha[((__iti-1)+((__itj-1)*_u_my_alpha._d[0]))]*_u_my_beta[((_tmpxx25[(__iti-1)]-1)+((__itji-1)*_u_my_beta._d[0]))])*_u_My_Gamma1[((_tmpxx26[(__iti-1)]-1)+((__itj-1)*_u_My_Gamma1._d[0]))]);
      }
      __itji++;
    }
  }
  crt::Array<double,2> _tmpxx28(1,_u_my_alpha._d[1]);
  crt::sum(_tmpxx28,_tmpxx27,"r");
  {
    int __iti;
    for (__iti = 1;__iti <= _tmpcall0._d[1];__iti++) {
      _u_Prob.at(1,(__iti-1)) = _tmpxx28[(__iti-1)];
    }
  }
  crt::Array<double,2> _u_tmp_sum(1,_u_Prob._d[1]);
  crt::sum(_u_tmp_sum,_u_Prob,"r");
  {
    int __iti;
    for (__iti = 1;__iti <= _tmpcall0._d[1];__iti++) {
      _u_Prob.at(0,(__iti-1)) = (_u_Prob[((__iti-1)*_u_Prob._d[0])] / _u_tmp_sum[(__iti-1)]);
    }
  }
  {
    int __iti;
    for (__iti = 1;__iti <= _tmpcall0._d[1];__iti++) {
      _u_Prob.at(1,(__iti-1)) = (_u_Prob[(1+((__iti-1)*_u_Prob._d[0]))] / _u_tmp_sum[(__iti-1)]);
    }
  }
  return;
}

/* -------------------------------------------------------------------------- */


/* -------------------------------------------------------------------------- */


#if defined(_MSC_VER)
#define ST_EXPORT __declspec(dllexport)
#else
#define ST_EXPORT
#endif

extern "C" {
#include <mex.h>
#include <sci_gateway.h>
#include <api_scilab.h>
#include <MALLOC.h>

int sci_myDec1_Process(char* fname, int)
{
  crt::init(1000000000);
  {
  //------------------------------------------------------------------------------

  crt::Array<double,2> _tmpcall0(pvApiCtx,1);
  int _u_DATA_SIZE;
  crt::getFromSci(_u_DATA_SIZE,pvApiCtx,2);
  int _u_NUM_STATES;
  crt::getFromSci(_u_NUM_STATES,pvApiCtx,3);
  crt::Array<int,2> _u_Ga_Inx(pvApiCtx,4);
  crt::Array<int,2> _u_Gb_Inx(pvApiCtx,5);
  crt::Array<int,2> _u_P_Ip(pvApiCtx,6);
  crt::Array<int,2> _u_P_State(pvApiCtx,7);
  crt::Array<int,2> _u_N_State(pvApiCtx,8);
  crt::Array<double,2> _u_My_Gamma1(pvApiCtx,9);

  //------------------------------------------------------------------------------

  crt::Array<double,2,crt::heap_allocator> _u_Prob(crt::ARRAY,0,0);

  //------------------------------------------------------------------------------
  // Call main function

  Dec1_Process_0(_u_Prob,_tmpcall0,_u_DATA_SIZE,_u_NUM_STATES,_u_Ga_Inx,_u_Gb_Inx,_u_P_Ip,_u_P_State,_u_N_State,_u_My_Gamma1);

  //------------------------------------------------------------------------------

  crt::toSciArray(pvApiCtx, nbInputArgument(pvApiCtx) + 1, _u_Prob);
  AssignOutputVariable(pvApiCtx, 1) = nbInputArgument(pvApiCtx) + 1;
  }
  crt::terminate();
  return 0;
}


ST_EXPORT int C2F(sci_myDec1_Process)()
{
  Rhs = Max(0, Rhs);
  if(pvApiCtx == NULL) {
    pvApiCtx = (StrCtx*)MALLOC(sizeof(StrCtx));
  }
  pvApiCtx->pstName = strdup("myDec1_Process");
  sci_gateway(pvApiCtx->pstName, sci_myDec1_Process);
  return 0;
}
} // extern "C"


